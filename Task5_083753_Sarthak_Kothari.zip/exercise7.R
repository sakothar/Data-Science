#exr7
data_dtm<-DocumentTermMatrix(data_corpus)

#exr8
data_dtm