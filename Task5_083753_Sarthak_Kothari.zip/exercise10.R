#exr10
install.packages('wordcloud')
library(wordcloud)
wordcloud(data$text, min.freq=72, scale=c(3, 0.5),random.order = FALSE)
