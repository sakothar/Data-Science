#exr2
data$type<-as.factor(data$type)
str(data)
