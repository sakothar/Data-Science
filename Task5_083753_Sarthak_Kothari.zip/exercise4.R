#exr4
install.packages('tm')
library(tm)
data_corpus<-VCorpus(VectorSource(data$text))
data_corpus
