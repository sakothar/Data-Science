data <- read.csv(file="C:/Users/harsh/Desktop/R/Sarthak/task5/spam_ham.csv")
data
