#exr6
data_corpus<-tm_map(data_corpus,content_transformer(tolower))
data_corpus<-tm_map(data_corpus,removeNumbers)
data_corpus<-tm_map(data_corpus,removePunctuation)
data_corpus<-tm_map(data_corpus,stripWhitespace)
as.character(data_corpus[[20]])
