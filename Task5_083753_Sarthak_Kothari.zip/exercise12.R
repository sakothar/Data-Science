#exr12

data_dtm__train_labels <- data[1:4460, ]$type #Training Label
data_dtm_train_labels
data_dtm_test_labels  <- data[4461:5574, ]$type # Test Label
data_dtm_test_labels
prop.table(table(data_dtm__train_labels))
prop.table(table(data_dtm_test_labels))
data_dtm_freq_train <- data_dtm_train[ , data_dtm_freq_words]
data_dtm_freq_test <- data_dtm_test[ , data_dtm_freq_words]
#If counts are greater than 0, convert into "Yes", otherwise, "NO"
convert_counts <- function(x) {
  x <- ifelse(x > 0, "Yes", "No")
}

# apply() to convert DTM dataset that has yes and no into numerical data. 
data_train <- apply(data_dtm_freq_train, MARGIN = 2, convert_counts)
data_test  <- apply(data_dtm_freq_test, MARGIN = 2, convert_counts)
install.packages('e1071')
library(e1071)
data_classifier <- naiveBayes(data_train,data_dtm__train_labels)
data_dtm_test_pred <- predict(data_classifier,data_test)
head(data_dtm_test_pred)
install.packages('gmodels')
library(gmodels)
CrossTable(data_dtm_test_pred, data_dtm_test_labels,
           prop.chisq = FALSE, prop.t = FALSE, prop.r = FALSE,
           dnn = c('predicted', 'actual'))
