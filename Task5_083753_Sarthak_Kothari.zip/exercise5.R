#exr5
inspect(data_corpus[1:3])
