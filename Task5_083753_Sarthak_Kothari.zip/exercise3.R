#exer3
table(data$type)