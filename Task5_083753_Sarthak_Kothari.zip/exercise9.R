#exr9
data_dtm_train<-data_dtm[1:4460,] # Training dataset
data_dtm_train
data_dtm_test<-data_dtm[4461:5574,] #Test datas
data_dtm_test
