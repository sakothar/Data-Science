#exr11
data_dtm_freq_words <- findFreqTerms(data_dtm_train, 5)
str(data_dtm_freq_words)
