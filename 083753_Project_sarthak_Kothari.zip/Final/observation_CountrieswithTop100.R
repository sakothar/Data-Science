#countries with highest number of universities in top 100
#times Data
df <- data.frame(timesData[1:100,])
p <- as.data.frame(table(df$country))
p

a1 <- ggplot(data = df, aes(x=country)) + ggtitle("Countries with Highest Ranked Universities - Times Data") + geom_bar() + geom_bar(aes(fill = country), position = position_stack(reverse = TRUE)) + scale_y_continuous(breaks = seq(0,60,5)) + coord_flip()
a1

#CWUR data
df_s <- data.frame(cwurData[1:100,])
p2 <- as.data.frame(table(df_s$country))
p2
a2 <- ggplot(data = df_s, aes(x=country)) + ggtitle("Countries with Highest Ranked Universities - CWUR Data")  + geom_bar() + geom_bar(aes(fill = country), position = position_stack(reverse = TRUE)) + scale_y_continuous(breaks = seq(0,60,5)) + coord_flip()
a2


#School & Country data
df_sh <- data.frame(school_and_country_table[1:100,])
p3 <- as.data.frame(table(df_sh$country))
p3

a3 <- ggplot(data = df_sh, aes(x=country)) + ggtitle("Countries with Highest Ranked Universities - School & Country Data") + geom_bar() + geom_bar(aes(fill = country), position = position_stack(reverse = TRUE)) + scale_y_continuous(breaks = seq(0,60,5)) + coord_flip()
a3

#grid for Times, CWUR and School&Country dataset
grid.arrange(a1,a2,a3,nrow = 2)

