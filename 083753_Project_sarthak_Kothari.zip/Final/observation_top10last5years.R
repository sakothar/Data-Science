#importing and reading datasets
cwurData <- read.csv("C:/Users/hp/Desktop/cwurData.csv")
timesData <- read.csv("C:/Users/hp/Desktop/timesData.csv")
shanghaiData <- read.csv("C:/Users/hp/Desktop/shanghaiData.csv")
school_and_country_table <- read.csv("C:/Users/hp/Desktop/school_and_country_table.csv")

#calling required libraries
library(ggplot2)
library(tidyverse)
library(grid)
library(gridExtra)
library(rpart)
library(tidyr)
library(dbplyr)

#Top 10 universities over past 5 years
cwur2011 <- filter(cwurData, year == "2011")
cwur2011_df <- data.frame(cwur2011[1:10,])
plot_2011 <- ggplot(data = cwur2011_df, aes(x=reorder(institution,world_rank), y=world_rank)) + geom_bar(stat="identity") + coord_flip() + ggtitle("Rank in 2011") + xlab("University Name") + ylab("World Rank")

cwur2012 <- filter(cwurData, year == "2012")
cwur2012_df <- data.frame(cwur2012[1:10,])
plot_2012 <- ggplot(data = cwur2012_df, aes(x=reorder(institution,world_rank), y=world_rank)) + geom_bar(stat="identity") + coord_flip() + ggtitle("Rank in 2012") + xlab("University Name") + ylab("World Rank")

cwur2013 <- filter(cwurData, year == "2013")
cwur2013_df <- data.frame(cwur2013[1:10,])
plot_2013 <- ggplot(data = cwur2013_df, aes(x=reorder(institution,world_rank), y=world_rank)) + geom_bar(stat="identity") + coord_flip() + ggtitle("Rank in 2013") + xlab("University Name") + ylab("World Rank")

cwur2014 <- filter(cwurData, year == "2014")
cwur2014_df <- data.frame(cwur2014[1:10,])
plot_2014 <- ggplot(data = cwur2014_df, aes(x=reorder(institution,world_rank), y=world_rank)) + geom_bar(stat="identity") + coord_flip()+ ggtitle("Rank in 2014") + xlab("University Name") + ylab("World Rank")

cwur2015 <- filter(cwurData, year == "2015")
cwur2015_df <- data.frame(cwur2015[1:10,])
plot_2015 <- ggplot(data = cwur2015_df, aes(x=reorder(institution,world_rank), y=world_rank)) + geom_bar(stat="identity") + coord_flip() + ggtitle("Rank in 2015") + xlab("University Name") + ylab("World Rank")

grid.arrange(plot_2012, plot_2013, plot_2014, plot_2015, ncol = 2)