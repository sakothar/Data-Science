library(dplyr)



options(warn = -1)
#top 10 universities of canada in 2015 by alumni employment
emp_2015 <- filter(cwurData, year == "2015")
canada_emp_2015 <- filter(emp_2015, country == "Canada")
ca_alu <- canada_emp_2015[order(-canada_emp_2015$alumni_employment),]
ca_employment <- data.frame(ca_alu[1:10,])
ca_alu_emp <- select(ca_employment, world_rank, institution, alumni_employment, national_rank, country, year, )
ca_alu_emp


#top 10 universities of USA in 2015 by alumni employment
emp_2015 <- filter(cwurData, year == "2015")
usa_emp_2015 <- filter(emp_2015, country == "USA")
us_alu <- usa_emp_2015[order(-usa_emp_2015$alumni_employment),]
us_employment <- data.frame(us_alu[1:10,])
us_alu_emp <- select(us_employment, world_rank, institution, alumni_employment, national_rank, country, year, )
us_alu_emp


#top 10 universities of UK in 2015 by alumni employment
emp_2015 <- filter(cwurData, year == "2015")
uk_emp_2015 <- filter(emp_2015, country == "United Kingdom")
uk_alu <- uk_emp_2015[order(-uk_emp_2015$alumni_employment),]
uk_employment <- data.frame(uk_alu[1:10,])
uk_alu_emp <- select(uk_employment, world_rank, institution, alumni_employment, national_rank, country, year, )
uk_alu_emp


ca<-ggplot(data = ca_alu_emp, aes(x=world_rank, y=trunc(alumni_employment))) + geom_point(aes(color = institution)) + xlab("World Rank") + ylab("Alumni Employment")+coord_flip()
us<-ggplot(data = us_alu_emp, aes(x=world_rank, y=trunc(alumni_employment))) + geom_point(aes(color = institution)) + xlab("World Rank") + ylab("Alumni Employment")+coord_flip()
uk<-ggplot(data = uk_alu_emp, aes(x=world_rank, y=trunc(alumni_employment))) + geom_point(aes(color = institution)) + xlab("World Rank") + ylab("Alumni Employment")+coord_flip()


grid.arrange(ca,us,uk, ncol=2)
