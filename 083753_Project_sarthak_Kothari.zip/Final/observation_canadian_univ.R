#Canadian Universities in the 2015 Times list

tcanada_2015 <- filter(timesData, year == "2015", country == "Canada")
nrow(tcanada_2015)
times_canada_2015_name <- select(tcanada_2015, world_rank, university_name, country, year)
times_canada_2015_name

#Canadian Universities in the 2015 CWUR list

cwur_canada_2015 <- filter(cwurData, year == "2015", country == "Canada")
nrow(cwur_canada_2015)
cwur_canada_2015_name <- select(cwur_canada_2015, world_rank, institution, country, year)
cwur_canada_2015_name
