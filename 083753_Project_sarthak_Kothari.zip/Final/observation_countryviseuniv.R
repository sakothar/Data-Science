timesData <- read.csv("C:/Users/hp/Desktop/timesData.csv")
a <- timesData$country[timesData$year == 2011]
wordcloud(a, min.freq = 500, random.order = FALSE)


cdata <- read.csv("C:/Users/hp/Desktop/cwurData.csv")


topc<-cdata %>%select(world_rank,institution,country,year)%>% filter(year==2011 )%>%group_by(country)%>%summarise(university_count=n())
p11<- ggplot(topc,aes(x=country,y=university_count))+geom_bar(stat="identity",fill="orchid4")+theme(axis.text.x = element_text(angle=90))+geom_text(aes(label=university_count),vjust=-.4,size=2)+labs(title="Countrywise University Count")
plot(p11)

topc<-cdata %>%select(world_rank,institution,country,year)%>% filter(year==2012 )%>%group_by(country)%>%summarise(university_count=n())
p12<- ggplot(topc,aes(x=country,y=university_count))+geom_bar(stat="identity",fill="orchid4")+theme(axis.text.x = element_text(angle=90))+geom_text(aes(label=university_count),vjust=-.4,size=2)+labs(title="Countrywise University Count")
plot(p12)


topc<-cdata %>%select(world_rank,institution,country,year)%>% filter(year==2013 )%>%group_by(country)%>%summarise(university_count=n())
p13<- ggplot(topc,aes(x=country,y=university_count))+geom_bar(stat="identity",fill="orchid4")+theme(axis.text.x = element_text(angle=90))+geom_text(aes(label=university_count),vjust=-.4,size=2)+labs(title="Countrywise University Count")
plot(p13)


topc<-cdata %>%select(world_rank,institution,country,year)%>% filter(year==2014 )%>%group_by(country)%>%summarise(university_count=n())
p14<- ggplot(topc,aes(x=country,y=university_count))+geom_bar(stat="identity",fill="orchid4")+theme(axis.text.x = element_text(angle=90))+geom_text(aes(label=university_count),vjust=-.4,size=2)+labs(title="Countrywise University Count")
plot(p14)


topc<-cdata %>%select(world_rank,institution,country,year)%>% filter(year==2015 )%>%group_by(country)%>%summarise(university_count=n())
p15<- ggplot(topc,aes(x=country,y=university_count))+geom_bar(stat="identity",fill="orchid4")+theme(axis.text.x = element_text(angle=90))+geom_text(aes(label=university_count),vjust=-.4,size=2)+labs(title="Countrywise University Count")
plot(p15)

