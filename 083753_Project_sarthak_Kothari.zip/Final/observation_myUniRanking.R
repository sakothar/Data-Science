#Ranking of myuniversity = University of Alberta

shanghaiData <- read.csv("C:/Users/hp/Desktop/shanghaiData.csv")
UCLB <- filter(shanghaiData, university_name == "University of Alberta")
shanghai <- qplot(world_rank, year, data = UCLB)
shanghai

timesData <- read.csv("C:/Users/hp/Desktop/timesData.csv")
UCLB1 <- filter(timesData, university_name == "University of Alberta")
times <- qplot(world_rank, year, data = UCLB)
times

p = ggplot() + geom_point(data = UCLB1, aes(x = world_rank, y = year), color = "blue") + geom_point(data = UCLB, aes(x = world_rank, y = year), color = "red") + xlab('World Rank') + ylab('Year') + scale_y_continuous(breaks = seq(2005,2015,1)) + scale_color_manual(values = c("shanghaiData" = "red", "timesData" = "blue"))
p

