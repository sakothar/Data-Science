library(ggplot2)
#install.packages("cowplot")
library(cowplot)

uni<-read.csv("C:/Users/hp/Desktop/timesData.csv",stringsAsFactor=FALSE)


#plot grid for Universities in USA based on international students

USuni<-subset(uni,country=="United States of America")
nyear<-unique(uni$year)
p2<-ggplot(USuni,aes(color=factor(year)))
for(i in nyear) {
  USyear<-subset(USuni,year==i)
  us_d= geom_bin2d(data=USyear,aes(x=international,y=year))
  p2<-p2+us_d
}
plot(p2)


#plot grid for Universities in Canada based on international students

CAuni<-subset(uni,country=="Canada")
nyear<-unique(uni$year)
p3<-ggplot(CAuni,aes(color=factor(year)))
for(i in nyear) {
  cayear<-subset(CAuni,year==i)
 ca_d= geom_bin2d(data=cayear,aes(x=international,y=year))  
  p3<-p3+ca_d
}

plot(p3)




plot_grid(p2, p3, labels = c( "USA", "Canada"))