library(ggplot2)
#install.packages("cowplot")
library(cowplot)

uni<-read.csv("C:/Users/hp/Desktop/timesData.csv",stringsAsFactor=FALSE)

#plot grid for Universities in Euopean countries based on research

europe<-c("Italy","Austria","Greece","France","Luxembourg","Hungary","Latvia","Ukraine","Sweden","Norway","Portugal","Lithuania","Switzerland","Germany","Spain","Turkey","Czech Republic","Cyprus","Romania","Belarus","Republic of Ireland","Netherlands","Unted Kingdom","Slovenia", "Serbia","Belgium","Poland","Estonia","Slovakia")
EU<-subset(uni,(country %in% europe))
nyear<-unique(uni$year)
p<-ggplot(EU,aes(color=factor(year)))+scale_x_continuous(limits=c(0,100))


for(i in nyear) {
  euyear<-subset(EU,year==i)
  eu_d= geom_density(data=euyear,aes(x=research))
  p<-p+eu_d
}
plot(p)


#plot grid for Universities in USA based on research

USuni<-subset(uni,country=="United States of America")
nyear<-unique(uni$year)
p2<-ggplot(USuni,aes(color=factor(year)))
for(i in nyear) {
  USyear<-subset(USuni,year==i)
  us_d= geom_density(data=USyear,aes(x=research))
  p2<-p2+us_d
}
plot(p2)


#plot grid for Universities in Canada based on research

CAuni<-subset(uni,country=="Canada")
nyear<-unique(uni$year)
p3<-ggplot(CAuni,aes(color=factor(year)))
for(i in nyear) {
  cayear<-subset(CAuni,year==i)
  ca_d= geom_density(data=cayear,aes(x=research))
  p3<-p3+ca_d
}
plot(p3)


#plot grid for Universities in Asian countries based on research

asia<-c("China","India","Indonesia","Pakistan","Bangladesh","Japan","Philippines","Viet Nam","Turkey","Iran","Thailand","Myanmar","South Korea","Iraq","Afghanistan","Saudi Arabia","Uzbekistan","Malaysia","Nepal","Yemen","North Korea","Sri Lanka","Kazakhstan","Syria","Cambodia","Jordan","Azerbaijan","United Arab Emirates","Tajikistan","Israel","Laos","Kyrgyzstan","Lebanon","Turkmenistan","Singapore","State of Palestine","Oman","Kuwait","Georgia","Mongolia","Armenia","Qatar","Bahrain","Timor-Leste","Cyprus","Bhutan","Maldives","Brunei","Taiwan","Hong Kong","Macao")
asiauni<-subset(uni,(country %in% asia))
nyear<-unique(uni$year)
p4<-ggplot(asiauni,aes(color=factor(year)))+scale_x_continuous(limits=c(0,100))


for(i in nyear) {
  asiayear<-subset(asiauni,year==i)
  asia_d= geom_density(data=asiayear,aes(x=research))
  p4<-p4+asia_d
}
plot(p4)


plot_grid(p, p2, p3, p4, labels = c("Europe", "USA", "Canada","Asia"))