#ranking of Alberta university in all times
shanghaiData <- read.csv("C:/Users/hp/Desktop/shanghaiData.csv")
camb <- filter(shanghaiData, university_name == "University of Alberta")
camb

#ranking in terms of research of Alberta university in all times
timesData <- read.csv("C:/Users/hp/Desktop/timesData.csv")
camb1 <- filter(timesData, university_name == "University of Alberta")
res <- select(camb1, world_rank, university_name, research, year)
res1 <- res[order(res$research),]
res1

resgraph <- ggplot(res) +ggtitle("Research graph")+ geom_point(aes(y = research, x = year), shape = 19,size = 3, color='blue') + geom_smooth(aes(y = research, x = year),method ='loess',formula = y~x, color='red') 
resgraph


#ranking in terms of teaching of Alberta university in all times
timesData <- read.csv("C:/Users/hp/Desktop/timesData.csv")
camb1 <- filter(timesData, university_name == "University of Alberta")
teach <- select(camb1, world_rank, university_name, teaching, year)
teach1 <- teach[order(teach$teaching),]
teach1



teachgraph <- ggplot(teach) +ggtitle("Teaching graph") + geom_point(aes(y = teaching, x =year), shape = 19,size = 3, color='red') + geom_smooth(aes(y = teaching, x = year),method ='loess',formula = y~x, color='blue')
teachgraph


grid.arrange(resgraph, teachgraph ,nrow = 2)
