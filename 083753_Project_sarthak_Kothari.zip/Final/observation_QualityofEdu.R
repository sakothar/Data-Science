#Quality of Education and FAcuty in Canada

cwur2015 <- filter(cwurData, year == "2015", country == "Canada")
cwur2015_df <- data.frame(cwur2012[1:10,])
cwur2015_df

#Quality of education for top 10 universities in the world
ggplot(data = cwur2015_df, aes(x=reorder(institution, -world_rank), y=quality_of_education)) + geom_bar(stat="identity") + coord_flip() + ggtitle("Quality of Education of top 10 universities") + xlab("University Name") + ylab("Quality of education")

#Quality of education vs Quality of Faculty for top 10 universities in the world
ggplot(data = cwur2015_df, aes(x=quality_of_education, y=quality_of_faculty)) + geom_point(aes(fill = institution)) + xlab("Quality of Education") + ylab("Quality of Faculty")
