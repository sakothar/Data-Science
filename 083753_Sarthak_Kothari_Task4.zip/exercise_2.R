AMZN <- read.csv("E:/Lakehead University/sarthak/Assignment 4/AMZN.csv", header = TRUE)
AMZN
AMZN<- AMZN[order(AMZN$Date),]
AMZN
amzn_ts<- ts(AMZN$Close, frequency = 12 , start=c(2008,3))
plot.ts(amzn_ts)

