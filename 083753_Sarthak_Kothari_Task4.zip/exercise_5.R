install.packages("forecast")
library("forecast")

##5.a

AMZN <- read.csv("E:/Lakehead University/sarthak/Assignment 4/AMZN.csv", header = TRUE)
AMZN
AMZN<- AMZN[order(AMZN$Date),]
AMZN
amzn_ts1<- ts(AMZN$Close, frequency = 12 , start=c(2008,3))
amzn_ts1<-HoltWinters(amzn_ts1,gamma=F)
plot(amzn_ts1)

##5.b

amzn_ts2<- forecast(amzn_ts1,h=19)
plot(amzn_ts2)