AMZN <- read.csv("E:/Lakehead University/sarthak/Assignment 4/AMZN.csv", header = TRUE)
AMZN <- AMZN[c(1:6), ]
AMZN

