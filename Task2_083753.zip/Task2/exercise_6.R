setNames(cbind(rownames(ex3), ex3, row.names = NULL), c("States.Name", "State_abb", "Population", "Income", "Illiteracy", "Life.Exp", "Murder", "HS.Grad", "Frost", "Area", "State_region"))
ex3

ggplot() + geom_histogram(aes(x=ex3$Population)) + ylab('Number of States') + xlab('Population (thousands)')

ggplot(ex3, aes(x=Population)) + geom_histogram() + facet_wrap(state.region ~ .)

