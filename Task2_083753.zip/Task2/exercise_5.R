library(ggplot2)
ggplot(ex3) + geom_point(aes(y = Life.Exp, x = Illiteracy), shape = 19, size = 2) + geom_smooth(aes(y = Life.Exp, x = Illiteracy), method = 'loess', formula = y~x)

