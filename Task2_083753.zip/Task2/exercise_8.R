library(ggplot2)
ex8<- data.frame(state.x77,state.abb,state.region)

ex8$IncomeGroup[ex3$Income <= 4200] = "Low"
ex8$IncomeGroup[ex3$Income > 4200 & ex3$Income <= 4700] = "Medium"
ex8$IncomeGroup[ex3$Income > 4700] = "High"

m<-ggplot(data=ex8, aes(x = Illiteracy, y = Life.Exp, size=Population)) + 
  scale_color_manual(values = c("North Central" = "red", "South" = "blue",
                                "Northeast" = "green", "West" = "violet"))

m +  facet_wrap(.~ex8$IncomeGroup) +geom_smooth(method = loess) +  geom_text(aes(label = state.abb, color = factor(state.region)))
