ex2<- data.frame(state.x77)

row.names(ex2[which.max(ex1$Income),])
