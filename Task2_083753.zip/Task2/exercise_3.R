ex3<- data.frame(state.x77,state.abb,state.region)

ex3

write.csv(ex3, file = "G:/Masters/Sem 2/Data Science/assignment 2/states.csv")
