library(ggplot2)
ex3<- data.frame(state.x77,state.abb,state.region)
ex3

colnames(ex3)[which(names(ex3) == "state.abb")] <- "states_abb"
ggplot(ex3, aes(Illiteracy,Life.Exp)) + geom_point() 


ggplot(ex3, aes(Illiteracy,Life.Exp)) + geom_text(aes(label=state.abb))


hist(ex3$Murder, breaks = 5, main = 'Histogram of Murder', xlab = "Murder")


barplot(prop.table(table(state.region)), xlab = "Regions", ylab = "Frequency")

