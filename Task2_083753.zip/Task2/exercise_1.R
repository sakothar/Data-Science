ex1<- data.frame(state.x77)

length(ex1$Income[ex1$Income <4300])
