library(ggplot2)
ggplot(data=ex3, aes(x = Illiteracy, y = Life.Exp, color = state.region)) + geom_point() + scale_color_manual(values = c("North Central" = "red", "South" = "blue", "Northeast" = "green", "West" = "violet"))
