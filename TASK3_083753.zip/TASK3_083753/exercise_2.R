install.packages("lubridate")

library(lubridate)


date_sep <- c("27-09-2017", "28-09-2017", "29-09-2017")
date <- as.Date(date_sep, format = "%d-%m-%Y")

wday(date, label = TRUE)

