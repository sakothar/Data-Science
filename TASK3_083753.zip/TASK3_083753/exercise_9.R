cars_m_h_s = cars_m_h %>% slice(10:35) %>% filter(mpg>20, hp>100)
cars_m_h_s

