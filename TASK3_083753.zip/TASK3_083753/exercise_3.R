View(mtcars)

library(tidyverse)

select(mtcars, -hp)
