View(mtcars)

select(mtcars, mpg, hp, vs, am, gear)
