install.packages("tidyr")
install.packages("stringr")
install.packages("dplyr")

library(tidyr)
library(stringr)
library(dplyr)

setwd("G:/Masters/Sem 2/Data Science/assignment 3")
FILES <- list.files( pattern = ".txt")
for (i in 1:length(FILES)) {
  FILE=read.table(file=FILES[i],header=T)
  write.csv(FILE,file=paste0("G:/Masters/Sem 2/Data Science/assignment 3/",sub(".txt","",FILES[i]),".csv"))
}

x <- read.csv("G:/Masters/Sem 2/Data Science/assignment 3/sales.csv")

x

x %>% mutate(currency = str_extract(sales,"\\$|�") ) %>% 
  mutate(raw_amount = str_replace_all(sales, ",|\\$|�", "") ) %>%
  mutate(amount = as.numeric(raw_amount)) %>%
  mutate(Pound_to_USD = ifelse(currency == '$', amount, ifelse(currency == '�', round(amount*1.29,2), NA)))
