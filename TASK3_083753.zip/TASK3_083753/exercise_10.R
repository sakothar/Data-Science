cars_m_h = setNames(cbind(rownames(cars_m_h),cars_m_h, row.names= NULL), c('Model','mpg', 'hp'))

cars_m_h %>% filter( Model == "Lotus Europa")
