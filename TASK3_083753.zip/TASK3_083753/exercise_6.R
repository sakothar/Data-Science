cars_m_h = mtcars %>% select(mpg, hp) %>% rename(miles_per_gallon = mpg, horse_power = hp)
cars_m_h

cars_m_h %>% rename(mpg = miles_per_gallon, hp = horse_power)
