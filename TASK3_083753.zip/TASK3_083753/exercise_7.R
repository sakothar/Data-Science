cars_m_h = mtcars %>% select(mpg, hp)

cars_m_h_s = cars_m_h %>% slice(10:35)
cars_m_h_s
