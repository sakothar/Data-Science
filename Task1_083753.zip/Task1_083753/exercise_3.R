library(ggplot2)
dataset = read.csv('mydata100.csv')

ggplot(dataset) + geom_point(aes(x = pretest, y = posttest), shape = 18, size = 3) + ggtitle("Exercise 3 (A)")


ggplot(dataset) + geom_point(aes(x = pretest, y = posttest), shape = 18, size = 3) + geom_smooth(aes(x = pretest, y = posttest), method = 'loess', formula = y~x) + ggtitle("Exercise 3 (B)")


ggplot(dataset) + geom_point(aes(x = pretest, y = posttest), shape = 18, size = 3) + geom_smooth(aes(x = pretest, y = posttest), method = 'lm', formula = y~x) + ggtitle("Exercise 3 (C)")


ggplot(dataset) + geom_point(aes(x = pretest, y = posttest, shape = gender)) + geom_smooth(aes(x = pretest, y = posttest, linetype = gender), method = 'lm', formula = y~x) + ggtitle("Exercise 3 (D)")


ggplot(dataset) + geom_point(aes(x = pretest, y = posttest), shape = 18, size = 3) + geom_smooth(aes(x = pretest, y = posttest), method = 'lm', formula = y~x) + facet_grid(gender ~ .) + ggtitle("Exercise 3 (E)")



