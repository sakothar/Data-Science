install.packages("UsingR")
library(UsingR)
library(ggplot2)

dataset = read.csv('mydata100.csv')

ggplot(dataset, aes(x = posttest)) + geom_histogram(aes(y = ..density..), fill = "black",
        color = "white") + geom_density(color = "black") + geom_rug() + ggtitle("Exercise 2 (A)")


ggplot(dataset, aes(x = posttest)) + geom_histogram(color = "white") + facet_grid(gender ~ .)+ ggtitle("Exercise 2 (B)")

