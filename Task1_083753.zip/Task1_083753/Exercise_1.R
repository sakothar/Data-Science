library(ggplot2)
dataset = read.csv('mydata100.csv')


ggplot(data = dataset, aes(x = workshop)) + geom_bar() + ggtitle("Excercise 1 (A)") + scale_y_continuous(breaks = seq(0,30,5))


ggplot(data = dataset, aes(x = workshop)) + geom_bar() + coord_flip() + ggtitle("Exercise 1 (B)") + scale_y_continuous(breaks = seq(0,30,5))


ggplot(data = dataset, aes(x = workshop)) + geom_bar(aes(fill = workshop), position = position_stack(reverse = TRUE)) + ggtitle("Exercise 1 (C)") + scale_y_continuous(breaks = seq(0,30,5))


ggplot(data = dataset, aes(x = gender)) + geom_bar(aes(fill = workshop), position = position_stack(reverse = TRUE)) + ggtitle("Exercise 1 (D)") + scale_y_continuous(breaks = seq(0,55,5))

