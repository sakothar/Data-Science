# PREDICTING DECISION TREE FROM EXERCISE 4
predictingtheweather <- predict(rainfallchances,weather)
head(predictingtheweather)
table(predictingtheweather,weather$RainTomorrow)
plot(predictingtheweather)
