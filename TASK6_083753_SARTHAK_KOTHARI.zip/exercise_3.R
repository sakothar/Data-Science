# COMPARISION OF PACKAGES
#importing weather data from R using rattle.data package

install.packages("rattle.data")
library(rattle.data)

View(weather)
summary(weather) #display summarised data of weather

# USING TREE PACKAGE
library(tree)
tree.decitree <- tree(RainTomorrow~Cloud3pm+Sunshine,method = "class",data=weather)
plot(tree.decitree)
text(tree.decitree ,all=TRUE,pretty = TRUE,splits = TRUE, cex = 1)
summary(tree.decitree)

#OBTAINED OBSERVATIONS
# 1 - IT WONT RAIN IF THE VALUE OF THE cloudat3pm IS LESS THAN 6.5
# 2 - THE SUNSHINE IS CHECKED IF THE cloudat3pm IS GREATER THAN 6.5 AND ALSO IT PREDICTS THAT IT WONT RAIN IF THE SUNSHINE IS GREATER THAN 9.3
# 3 - IT RAINS IF THE SUNSHINE IS LESS THAN 0.5 AND WHEN IT IS BETWEEN 8.75 AND 9.3

# CTREE PACKAGE
library(party)
ctree.decitree <- ctree(RainTomorrow~Cloud3pm+Sunshine,data=weather)
plot(ctree.decitree)

#WE OBTAIN SIMILIAR RESULTS USING CTREE


#DIFFERENCE
# The biggest difference between the packages is that the decision making capability at cloudat3pm
