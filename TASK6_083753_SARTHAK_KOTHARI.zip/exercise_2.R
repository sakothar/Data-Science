# DECISION TREE 
install.packages("tree")
library(tree)

#plot decision tree for Play Golf dataset
decitree<- tree(play~outlook+windy+humidity,method = "class",data=dataset)

plot(decitree)

#Print labels on decision tree
text(decitree ,all=TRUE,pretty = TRUE,splits = TRUE, cex = 1)

#view decision tree
head(decitree)
decitree 